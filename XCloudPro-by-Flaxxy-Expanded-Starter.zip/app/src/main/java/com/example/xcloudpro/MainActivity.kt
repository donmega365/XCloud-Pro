package com.example.xcloudpro

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 12, 18)
    private val panel = Color.rgb(13, 27, 38)
    private val green = Color.rgb(0, 230, 145)
    private lateinit var status: TextView
    private lateinit var serverSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(20))
        }

        content.addView(label("XCLOUD PRO", 30, green, true))
        content.addView(label("by Flaxxy • Play anywhere • Anytime", 14, Color.LTGRAY))
        content.addView(space(12))
        val authCard = card()
        authCard.addView(label("ACCOUNT", 17, Color.WHITE, true))
        authCard.addView(label("Microsoft authentication opens the official Microsoft page; native OAuth is not configured in this starter.", 13, Color.LTGRAY))
        authCard.addView(Button(this).apply {
            text = "Sign in with Microsoft"
            setOnClickListener { openUrl("https://login.live.com/") }
        })
        authCard.addView(Button(this).apply {
            text = "Create Microsoft account"
            setOnClickListener { openUrl("https://signup.live.com/") }
        })
        content.addView(authCard)
        content.addView(space(16))

        val card = card()
        card.addView(label("VPN CONNECTION", 17, Color.WHITE, true))
        status = label("Not connected — VPN backend not configured", 14, Color.LTGRAY)
        card.addView(status)
        card.addView(space(10))
        val vpnButton = Button(this).apply {
            text = "Configure VPN backend"
            setTextColor(Color.BLACK)
            setBackgroundColor(green)
            setOnClickListener {
                status.text = "No VPN tunnel configured. Add a real WireGuard/OpenVPN backend first."
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("VPN not configured")
                    .setMessage("This starter app does not route traffic yet. To enable a real VPN, deploy a VPN server and integrate a maintained client library (for example, WireGuard's Android tunnel library) with proper keys and Android VPN permission approval.")
                    .setPositiveButton("OK", null).show()
            }
        }
        card.addView(vpnButton)
        content.addView(card)
        content.addView(space(16))

        val serverCard = card()
        serverCard.addView(label("SELECT SERVER", 17, Color.WHITE, true))
        serverCard.addView(label("Demo list only — selecting a region does not change your IP.", 13, Color.LTGRAY))
        serverSpinner = Spinner(this)
        val regions = listOf(
            "Choose region",
            "Pakistan 1 — Karachi (not configured)", "Pakistan 2 — Lahore (not configured)",
            "India 1 — Mumbai (not configured)", "India 2 — Delhi (not configured)",
            "USA 1 — East (not configured)", "USA 2 — West (not configured)",
            "UAE 1 — Dubai (not configured)", "UAE 2 — Abu Dhabi (not configured)",
            "Russia 1 (not configured)", "Russia 2 (not configured)",
            "Japan 1 — Tokyo (not configured)", "Japan 2 — Osaka (not configured)",
            "Germany 1 (not configured)", "Germany 2 (not configured)",
            "Indonesia 1 (not configured)", "Indonesia 2 (not configured)",
            "United Kingdom 1 (not configured)", "Canada 1 (not configured)",
            "Singapore 1 (not configured)", "France 1 (not configured)"
        )
        serverSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, regions)
        serverCard.addView(serverSpinner)
        content.addView(serverCard)
        content.addView(space(16))

        val gameCard = card()
        gameCard.addView(label("CLOUD GAMING", 17, Color.WHITE, true))
        gameCard.addView(label("Open Xbox Cloud Gaming in your browser. Availability depends on region, account and subscription.", 14, Color.LTGRAY))
        val play = Button(this).apply {
            text = "Open Xbox Cloud Gaming"
            setOnClickListener {
                openUrl("https://www.xbox.com/play")
            }
        }
        gameCard.addView(play)
        val guide = Button(this).apply {
            text = "Open Better xCloud guide"
            setOnClickListener { openUrl("https://better-xcloud.github.io/") }
        }
        gameCard.addView(guide)
        content.addView(gameCard)
        content.addView(space(16))
        content.addView(label("Security note", 16, green, true))
        content.addView(label("Never embed private VPN keys in a public APK. Use a secure provisioning flow, authenticated server configs, and a maintained VPN protocol implementation.", 13, Color.LTGRAY))

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
        elevation = dp(2).toFloat()
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(4)
        layoutParams = lp
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(8))
        }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "No browser available", Toast.LENGTH_SHORT).show()
        }
    }
}
