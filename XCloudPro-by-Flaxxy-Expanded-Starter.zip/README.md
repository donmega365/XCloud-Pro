# XCloud Pro — Android starter project

This is a starter Android Studio project for an app named **XCloud Pro**. It includes:
- Dark mobile UI
- Demo server/region selector (does not change network routing)
- Launcher links for Xbox Cloud Gaming and Better xCloud
- A clear placeholder for VPN setup

## Important: VPN is NOT implemented yet
This project does not create a VPN tunnel and does not change your public IP. A genuine VPN requires:
1. A server you control, deployed with a maintained VPN protocol (WireGuard is a common option).
2. Android VPN permission flow and a maintained client/tunnel library.
3. Secure configuration delivery and key management.
4. Testing for DNS leaks, IPv6 handling, reconnects, and kill-switch behavior.

Do not put server private keys or shared secrets inside a public APK. The included VPN button intentionally explains that no backend is configured.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Install the Android SDK Platform 35 and a compatible JDK (Android Studio's bundled JDK is usually easiest).
4. Allow Gradle sync.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location.

The APK cannot be compiled inside this chat. You will need Android Studio/Gradle or a properly configured CI build runner. Android Studio may suggest a Gradle/plugin update depending on your installed version.

## Android version
Minimum SDK is 23 (Android 6.0). It is intended to be compatible with many older Android phones, but actual testing is required.

## Next development steps
- Choose your VPN protocol/server provider (WireGuard recommended for a first implementation).
- Deploy and secure the VPN server.
- Integrate a maintained Android tunnel library and implement Android's VPN permission approval.
- Replace the demo region list with real endpoint/config provisioning.
- Add connection state, failure handling, and secure config storage.
