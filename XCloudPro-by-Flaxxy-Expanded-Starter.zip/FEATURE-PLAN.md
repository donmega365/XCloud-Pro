# XCloud Pro by Flaxxy — feature plan and reality check

## Region labels in the demo
The app/admin panel can list two *labels* per requested country, but labels are not servers:
Pakistan 1/2, India 1/2, USA 1/2, UAE/Dubai 1/2, Russia 1/2, Japan 1/2, Germany 1/2, Indonesia 1/2, plus UK, Canada, Singapore, France.
Each location needs a separately deployed VPN endpoint, public IP/hostname, firewall rules, routing, monitoring, and secure WireGuard configuration before it can work.

## Free hosting and a Pakistan endpoint
There is no dependable way to create many real global VPN exit locations for free just by writing an app. Cloud providers may offer limited trials/free tiers, but availability, quotas, payment verification, and terms vary. A Pakistan exit server needs a machine and Pakistani internet connection in Pakistan; a cloud server in another country cannot become a Pakistani exit just because the UI says Pakistan.
A spare always-on computer/router on a Pakistan home connection can sometimes be configured as a VPN endpoint, but requires router/firewall setup and may be blocked by CGNAT/ISP restrictions. It is not something the phone app alone can create.

## Cloud gaming
A VPN may change the apparent network region, but does not guarantee Xbox Cloud Gaming access, account eligibility, subscription eligibility, or good latency. A far-away VPN endpoint can increase lag. Follow Microsoft's service and regional availability rules.

## Microsoft account
The app may open Microsoft's official sign-in/create-account pages now. A true native Microsoft login must use Microsoft's supported MSAL Android library and a registered application/client ID plus redirect configuration. Do not collect Microsoft passwords in your own app or admin panel.

Official docs: https://learn.microsoft.com/en-us/entra/msal/android/

## Admin panel and AI
`admin-panel/index.html` is a local static mockup only. It has no authentication, server control, persistent storage, or real AI. Do not expose it on the internet as-is. A real admin backend needs authenticated admin accounts, role-based access, API validation, HTTPS, audit logs, and secure secret storage. AI should only be able to perform safe, explicitly authorized actions via a backend—not read private VPN keys or Microsoft tokens.

## APK build
The ZIP is source code, not a signed APK. Build it with Android Studio/Gradle on a computer or a properly configured CI runner, then test on an actual Android device. This chat cannot verify a built APK or operate deployed servers.
